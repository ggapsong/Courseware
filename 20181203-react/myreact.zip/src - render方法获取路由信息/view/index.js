import React,{Component} from "react";
export default class Index extends Component{
    render(){
        return (
            <h1>首页</h1>
        );
    }
}