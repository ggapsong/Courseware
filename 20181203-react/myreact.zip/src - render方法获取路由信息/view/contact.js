import React,{Component} from "react";
export default class Contact extends Component{
    componentDidMount() {
        // console.log(this.props);
        // setTimeout(()=>{
        //     //this.props.history.push("/about");
        //     //window.location.href = "/about";
        // },3000)
    }
    render(){

        return (
            <h1>联系我们</h1>
        );
    }
}