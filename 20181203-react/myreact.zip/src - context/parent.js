import React,{Component} from "react";
import Children from "./children";
export default class  Parent extends Component {
    render(){
        return (<Children/>);
    }
}