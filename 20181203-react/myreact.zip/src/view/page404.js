import React,{Component} from "react";
export default class Page404 extends Component{
    render(){
        return (
            <h1>页面飞走了</h1>
        );
    }
}