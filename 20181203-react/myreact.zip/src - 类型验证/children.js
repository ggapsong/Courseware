import React,{Component} from "react";
export default class  Children extends Component {
    render(){
        return (<div>{"hello react"}</div>);
    }
}