import React from "react";
import ReactDOM from  "react-dom";
import App from "./app";
import "./index.less";
//https://www.jianshu.com/p/616999666920
ReactDOM.render(
    <App/>,document.getElementById("root")
)