import React,{Component} from "react";
export default class Contact2 extends Component {
    render(){
        return <h1>联系我们2</h1>;
    }
}