import React,{Component} from "react";
export default class Page404 extends Component {
    render(){
        return <h1>页面跑丢了呢</h1>;
    }
}